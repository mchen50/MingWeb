<?php
	$login_username;
	$login_password;
	$signup_username;
	$signup_password;
	$email;
?>
