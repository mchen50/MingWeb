<?php
     include("test_ming.php");
     test_canAffort();
     test_checkBankAccount();
     test_insertBAccount();
     test_checkBank();
     test_insertBank();
     test_insertHasBank();
     test_checkCard();
     test_insertCard();

     test_enoughB2E();
    test_fetchCards();
     test_enoughC2E();

    test_transferBank();
    test_transferCard();   
    test_insertBankTransfer();
    test_insertCardTransfer();
    test_updateEaccBal();

    test_getEaccID();
    test_insertTransaction();
?>