b_account add balance, number not unique;
bank name nn, not unique
Card number varchar(20), company nn, balance nn, alter billing address to billing_address, exp_date change from datetime to date,balance double
transfer, amount double
eaccount balance double
transaction amount double