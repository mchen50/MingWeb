<?php
	/*This file should ensure that pages cannot be accessed without login
	The database should include a login(user_id,log_io,date_time) table. Check if user is
	online. Redirect to index if the user is not online.
	include("connection.php");*/
	$username = "null";//for addressing the user while online
?>
